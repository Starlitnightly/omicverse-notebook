"""Kernel-side preview builders for the OmicVerse JupyterLab plugin."""

from __future__ import annotations

import ast
from typing import Any, Dict, Mapping, Optional

import pandas as pd

DATAFRAME_MIME_TYPE = "application/vnd.omicverse.dataframe+json"
ANNDATA_MIME_TYPE = "application/vnd.omicverse.anndata+json"


def _json_safe_frame(frame: pd.DataFrame, max_rows: int, max_cols: int) -> Dict[str, Any]:
    preview = frame.iloc[:max_rows, :max_cols].copy()
    preview = preview.astype(object).where(pd.notna(preview), None)
    return {
        "columns": [str(col) for col in preview.columns],
        "index": [str(idx) for idx in preview.index],
        "data": preview.values.tolist(),
    }


def _df_payload(
    frame: pd.DataFrame,
    name: Optional[str] = None,
    max_rows: int = 40,
    max_cols: int = 12,
) -> Dict[str, Any]:
    return {
        "type": "dataframe",
        "name": name,
        "shape": [int(frame.shape[0]), int(frame.shape[1])],
        "dtypes": {str(col): str(dtype) for col, dtype in frame.dtypes.items()},
        "table": _json_safe_frame(frame, max_rows=max_rows, max_cols=max_cols),
    }


def _repr_payload(
    value: Any,
    name: Optional[str] = None,
    max_chars: int = 4000,
) -> Dict[str, Any]:
    try:
        text = repr(value)
    except Exception:
        text = "<unavailable>"
    return {
        "type": "content",
        "name": name,
        "content": text[:max_chars],
    }


def _matrix_payload(
    value: Any,
    name: Optional[str] = None,
    max_rows: int = 12,
    max_cols: int = 12,
) -> Dict[str, Any]:
    try:
        import numpy as np
    except Exception:
        return _repr_payload(value, name=name)

    try:
        from scipy import sparse
    except Exception:
        sparse = None

    array = value
    if sparse is not None and sparse.issparse(array):
        array = array[:max_rows, :max_cols].toarray()
    elif hasattr(array, "shape") and len(getattr(array, "shape", ())) >= 2:
        array = array[:max_rows, :max_cols]

    if not isinstance(array, np.ndarray):
        try:
            array = np.asarray(array)
        except Exception:
            return _repr_payload(value, name=name)

    if array.ndim == 1:
        array = array.reshape(-1, 1)
    if array.ndim != 2:
        return {
            "type": "array",
            "name": name,
            "shape": [int(dim) for dim in getattr(value, "shape", array.shape)],
            "dtype": str(getattr(value, "dtype", array.dtype)),
            "content": repr(value)[:4000],
        }

    table = {
        "columns": [str(i) for i in range(array.shape[1])],
        "index": [str(i) for i in range(array.shape[0])],
        "data": array.tolist(),
    }
    return {
        "type": "array",
        "name": name,
        "shape": [int(dim) for dim in getattr(value, "shape", array.shape)],
        "dtype": str(getattr(value, "dtype", array.dtype)),
        "table": table,
    }


def _pack_keys(keys: Any, limit: int) -> Dict[str, Any]:
    values = [str(key) for key in list(keys)]
    kept = values[:limit]
    return {
        "keys": kept,
        "total": len(values),
        "more": max(0, len(values) - len(kept)),
    }


def _mapping_previews(
    mapping: Mapping[str, Any],
    slot_name: str,
    max_items: int,
    max_rows: int,
    max_cols: int,
) -> Dict[str, Any]:
    previews: Dict[str, Any] = {}
    for key in list(mapping.keys())[:max_items]:
        label = f'{slot_name}["{key}"]'
        value = mapping[key]
        if isinstance(value, pd.DataFrame):
            previews[str(key)] = _df_payload(value, name=label, max_rows=max_rows, max_cols=max_cols)
        elif hasattr(value, "shape"):
            previews[str(key)] = _matrix_payload(value, name=label, max_rows=min(max_rows, 10), max_cols=min(max_cols, 10))
        else:
            previews[str(key)] = _repr_payload(value, name=label)
    return previews


def _anndata_payload(
    value: Any,
    name: Optional[str] = None,
    max_rows: int = 24,
    max_cols: int = 10,
    key_limit: int = 18,
    nested_preview_limit: int = 3,
) -> Dict[str, Any]:
    obs_pack = _pack_keys(value.obs.columns, key_limit)
    var_pack = _pack_keys(value.var.columns, key_limit)
    uns_pack = _pack_keys(value.uns.keys() if getattr(value, "uns", None) else [], key_limit)
    obsm_pack = _pack_keys(value.obsm.keys() if getattr(value, "obsm", None) else [], key_limit)
    layers_pack = _pack_keys(value.layers.keys() if getattr(value, "layers", None) else [], key_limit)

    return {
        "type": "anndata",
        "name": name,
        "summary": {
            "shape": [int(value.n_obs), int(value.n_vars)],
            "obs_columns": obs_pack["keys"],
            "obs_columns_total": obs_pack["total"],
            "obs_columns_more": obs_pack["more"],
            "var_columns": var_pack["keys"],
            "var_columns_total": var_pack["total"],
            "var_columns_more": var_pack["more"],
            "uns_keys": uns_pack["keys"],
            "uns_keys_total": uns_pack["total"],
            "uns_keys_more": uns_pack["more"],
            "obsm_keys": obsm_pack["keys"],
            "obsm_keys_total": obsm_pack["total"],
            "obsm_keys_more": obsm_pack["more"],
            "layers": layers_pack["keys"],
            "layers_total": layers_pack["total"],
            "layers_more": layers_pack["more"],
        },
        "previews": {
            "obs": _df_payload(value.obs, name=f"{name}.obs" if name else ".obs", max_rows=max_rows, max_cols=max_cols),
            "var": _df_payload(value.var, name=f"{name}.var" if name else ".var", max_rows=max_rows, max_cols=max_cols),
            "uns": _mapping_previews(value.uns, f"{name}.uns" if name else "uns", nested_preview_limit, max_rows, max_cols)
            if getattr(value, "uns", None)
            else {},
            "obsm": _mapping_previews(value.obsm, f"{name}.obsm" if name else "obsm", nested_preview_limit, max_rows, max_cols)
            if getattr(value, "obsm", None)
            else {},
            "layers": _mapping_previews(
                value.layers,
                f"{name}.layers" if name else "layers",
                nested_preview_limit,
                max_rows,
                max_cols,
            )
            if getattr(value, "layers", None)
            else {},
        },
    }


def preview_value(
    value: Any,
    name: Optional[str] = None,
    max_rows: int = 40,
    max_cols: int = 12,
    key_limit: int = 18,
    nested_preview_limit: int = 3,
) -> Dict[str, Any]:
    if isinstance(value, pd.DataFrame):
        return _df_payload(value, name=name, max_rows=max_rows, max_cols=max_cols)
    if isinstance(value, pd.Series):
        series_name = str(value.name) if value.name is not None else "value"
        return _df_payload(
            value.to_frame(name=series_name),
            name=name,
            max_rows=max_rows,
            max_cols=1,
        )
    if value.__class__.__name__ == "AnnData":
        return _anndata_payload(
            value,
            name=name,
            max_rows=min(max_rows, 24),
            max_cols=min(max_cols, 10),
            key_limit=key_limit,
            nested_preview_limit=nested_preview_limit,
        )
    if hasattr(value, "shape"):
        return _matrix_payload(value, name=name, max_rows=min(max_rows, 12), max_cols=min(max_cols, 12))
    return _repr_payload(value, name=name)


def _resolve_node(node: ast.AST, namespace: Mapping[str, Any]) -> Any:
    if isinstance(node, ast.Name):
        if node.id not in namespace:
            raise KeyError(f'Variable "{node.id}" not found')
        return namespace[node.id]

    if isinstance(node, ast.Attribute):
        base = _resolve_node(node.value, namespace)
        if node.attr.startswith("_"):
            raise KeyError("Private attributes are not allowed")
        return getattr(base, node.attr)

    if isinstance(node, ast.Subscript):
        base = _resolve_node(node.value, namespace)
        key = _resolve_subscript_key(node.slice)
        return base[key]

    raise KeyError("Only names, attributes, and string/integer subscripts are allowed")


def _resolve_subscript_key(node: ast.AST) -> Any:
    if isinstance(node, ast.Constant) and isinstance(node.value, (str, int)):
        return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub) and isinstance(node.operand, ast.Constant):
        if isinstance(node.operand.value, int):
            return -node.operand.value
    raise KeyError("Only string and integer subscripts are allowed")


def resolve_expression(expression: str, namespace: Mapping[str, Any]) -> Any:
    expression = expression.strip()
    if not expression:
        raise KeyError("Expression is empty")
    tree = ast.parse(expression, mode="eval")
    return _resolve_node(tree.body, namespace)


def preview_variable(
    expression: str,
    namespace: Optional[Mapping[str, Any]] = None,
    **kwargs: Any,
) -> Dict[str, Any]:
    if namespace is None:
        ipython = get_ipython()  # type: ignore[name-defined]
        if ipython is None:
            raise RuntimeError("No active IPython shell was found")
        namespace = ipython.user_ns

    value = resolve_expression(expression, namespace)
    return preview_value(value, name=expression, **kwargs)


def enable_formatters(ipython: Optional[Any] = None, **kwargs: Any) -> bool:
    if ipython is None:
        ipython = get_ipython()  # type: ignore[name-defined]
    if ipython is None:
        return False

    dataframe_formatter = ipython.display_formatter.formatters[DATAFRAME_MIME_TYPE]
    dataframe_formatter.for_type_by_name(
        "pandas.core.frame",
        "DataFrame",
        lambda value, printer, cycle: preview_value(value, **kwargs),
    )
    dataframe_formatter.for_type_by_name(
        "pandas.core.series",
        "Series",
        lambda value, printer, cycle: preview_value(value, **kwargs),
    )

    try:
        import anndata

        anndata_formatter = ipython.display_formatter.formatters[ANNDATA_MIME_TYPE]
        anndata_formatter.for_type(
            anndata.AnnData,
            lambda value, printer, cycle: preview_value(value, **kwargs),
        )
    except Exception:
        pass

    return True


def load_ipython_extension(ipython: Optional[Any]) -> None:
    enable_formatters(ipython)
